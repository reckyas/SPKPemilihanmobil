<div class="mb-2">
    <label for="<?php echo e($name); ?>">
        <span class="text-slate-700 font-semibold"><?php echo e($label); ?></span>
        <input type="text"
            class="px-3 py-2 border-2 border-slate-500 mt-1 rounded-lg outline-none focus:ring-2 focus:ring-blue-400 text-slate-700 font-semibold w-full disabled:bg-slate-200 disabled:text-slate-500 disabled:cursor-not-allowed"
            name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" placeholder="<?php echo e($placeholder); ?>"
            <?php if($required): ?> required <?php endif; ?>
            <?php if($value): ?> value="<?php echo e($value); ?>" <?php else: ?> value="<?php echo e(old($name)); ?>" <?php endif; ?>
            <?php if($disable): ?> disabled <?php endif; ?>>
        <?php if($error): ?>
            <p><?php echo e($error['nama']); ?></p>
        <?php endif; ?>
    </label>
</div>
<?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/components/input-text.blade.php ENDPATH**/ ?>