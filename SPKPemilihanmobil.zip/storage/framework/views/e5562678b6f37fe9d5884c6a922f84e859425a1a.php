<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto max-w-5xl p-5 sm:p-10">
        <div class="border border-red-300 shadow-md rounded-lg overflow-hidden">
            <div class="bg-red-500 p-3 font-semibold sm:p-6 sm:text-2xl text-slate-200">
                Cari mobil yang anda inginkan sesuai kriteria yang anda mau
            </div>
            <form action="<?php echo e(route('hasil-filter')); ?>" method="get">
                <div class="p-3 sm:p-6 sm:grid sm:grid-cols-2 sm:gap-2">
                    <?php $__currentLoopData = $data_filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7 = $component; } ?>
<?php $component = App\View\Components\InputSelect::resolve(['name' => ''.e($kriteria['name']).'','label' => ''.e($kriteria['label']).'','options' => $kriteria['options'],'required' => ''.e(false).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7)): ?>
<?php $component = $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7; ?>
<?php unset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="w-full px-6 mb-6 pb-4">
                    <button type="submit"
                        class="px-5 py-3 block tracking-wider hover:bg-red-700 shadow-sm shadow-red-900 text-center rounded-lg w-full bg-red-500 font-semibold text-slate-200 text-lg">
                        CARI
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/pages/home.blade.php ENDPATH**/ ?>