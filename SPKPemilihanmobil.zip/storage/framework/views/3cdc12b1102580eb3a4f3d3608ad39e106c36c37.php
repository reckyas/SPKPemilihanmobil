<?php $__env->startSection('title', 'Daftar Kriteria'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto w-full p-5 sm:p-10">
        <div class="flex sm:gap-2 flex-wrap sm:flex-nowrap">
            <div class="sm:w-3/12 mb-2 w-full">
                <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve(['active' => 'kriteria'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
            </div>
            <div class="sm:w-9/12 w-full">
                <div class="px-5 border rounded-lg">
                    <div class="my-2">
                        <h1 class="text-2xl text-slate-700 font-semibold">Daftar Kriteria</h1>
                    </div>
                    <div class="flex justify-end py-5 gap-2">
                        
                        <a href="/tambah-sub-kriteria"
                            class="px-3 py-2 font-semibold text-white bg-blue-500 hover:bg-blue-700 rounded-lg">Tambah Sub
                            Kriteria</a>
                    </div>
                    <div class="py-5 overflow-auto">
                        <?php if(session()->has('status')): ?>
                            <?php if(session()->get('status') == 'sukses'): ?>
                                <div class="p-3 mb-3 rounded-lg bg-green-500 text-white"><?php echo e(session()->get('message')); ?>

                                </div>
                            <?php else: ?>
                                <div class="p-3 mb-3 rounded-lg bg-red-500 text-white"><?php echo e(session()->get('message')); ?></div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <table class="table-auto border border-collapse border-slate-500 w-full">
                            <thead>
                                <tr class="bg-slate-300">
                                    <th class="border border-slate-600 px-1">No.</th>
                                    <th class="border border-slate-600 px-1">Nama</th>
                                    <th class="border border-slate-600 px-1">Bobot</th>
                                    <th class="border border-slate-600 px-1">Sub Kriteria</th>
                                    <th class="border border-slate-600 px-1">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="border border-slate-600 px-1 text-center"><?php echo e($loop->iteration); ?></td>
                                        <td class="border border-slate-600 px-1 font-semibold"><?php echo e($item->nama); ?></td>
                                        <td class="border border-slate-600 px-1 text-center"><?php echo e($item->bobot); ?></td>
                                        <td class="border border-slate-600 px-1">
                                            <?php $__currentLoopData = $item->sub_kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <ul>
                                                    <li class="flex justify-between px-2 py-1">
                                                        <div><?php echo e($sb->nama); ?></div>
                                                        <div><?php echo e($sb->bobot); ?></div>
                                                    </li>
                                                </ul>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td class="border border-slate-600 px-1 py-1">
                                            <a href="/kriteria/<?php echo e($item->id); ?>"
                                                class="px-2 py-1 bg-yellow-500 text-white rounded font-semibold mb-1 inline-block">E</a>
                                            <form action="post"></form>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="2" class="border border-slate-600 px-1 py-1 font-semibold text-center">Total Bobot</td>
                                    <td class="border border-slate-600 px-1 py-1 text-center"><?php echo e($total_bobot); ?></td>
                                    <td class="border border-slate-600 px-1 py-1"></td>
                                    <td class="border border-slate-600 px-1 py-1"></td>
                                </tr>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/pages/kriteria_all.blade.php ENDPATH**/ ?>