<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto max-w-md p-5 sm:p-10">
        <div class="border border-red-300 shadow-md rounded-lg overflow-hidden">
            <div class="bg-red-500 p-6 text-2xl text-slate-200">LOGIN</div>
            <div class="p-5">
                <?php if(session()->has('loginError')): ?>
                    <div class="bg-red-400 p-3 text-base text-red-900 rounded-lg">
                        Login gagal
                    </div>
                <?php endif; ?>
                <form action="/login" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-2">
                        <label for="email">
                            <span class="text-slate-700 font-semibold">Email</span>
                            <input placeholder="Masukan email" type="email" name="email" id="email" required
                                class="px-3 py-2 border-2 border-slate-500 mt-1 rounded-lg outline-none focus:ring-2 focus:ring-blue-400 text-slate-700 font-semibold w-full" value="<?php echo e(old('email')); ?>" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-xs">Email salah</span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                    </div>
                    <div class="mb-2">
                        <label for="password">
                            <span class="text-slate-700 font-semibold">Password</span>
                            <input placeholder="Masukan password" type="password" name="password" id="password" required
                                class="px-3 py-2 border-2 border-slate-500 mt-1 rounded-lg outline-none focus:ring-2 focus:ring-blue-400 text-slate-700 font-semibold w-full" />
                        </label>
                    </div>
                    <button type="submit"
                        class="w-full tracking-wider px-3 py-2 text-white font-semibold text-lg bg-red-500 hover:bg-red-600 shadow-md rounded-lg">Masuk</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/pages/login.blade.php ENDPATH**/ ?>