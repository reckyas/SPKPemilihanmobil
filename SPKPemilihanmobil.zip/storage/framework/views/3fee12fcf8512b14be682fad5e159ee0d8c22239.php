<?php $__env->startSection('title', 'Tambah Sub Kriteria'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto w-full p-5 sm:p-10">
        <div class="flex sm:gap-2 flex-wrap sm:flex-nowrap">
            <div class="sm:w-3/12 mb-2 w-full">
                <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve(['active' => 'kriteria'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
            </div>
            <div class="sm:w-9/12 w-full">
                <div class="px-5 border rounded-lg">
                    <div class="my-2">
                        <h1 class="text-2xl text-slate-700 font-semibold">Tambah Sub Kriteria</h1>
                    </div>
                    <div class="flex justify-end py-5">
                        <a href="<?php echo e(route('kriteria.index')); ?>"
                            class="px-3 py-2 font-semibold text-white bg-slate-500 hover:bg-slate-700 rounded-lg">Batal</a>
                    </div>
                    <div class="py-5">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-red-600"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php if(session()->has('status')): ?>
                            <?php if(session()->get('status') == 'sukses'): ?>
                                <div class="p-3 rounded-lg bg-green-500 text-white"><?php echo e(session()->get('message')); ?></div>
                            <?php else: ?>
                                <div class="p-3 rounded-lg bg-red-500 text-white"><?php echo e(session()->get('message')); ?></div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <form action="<?php echo e(route('sub-kriteria.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7 = $component; } ?>
<?php $component = App\View\Components\InputSelect::resolve(['name' => 'kriteria_id','label' => 'Kriteria','options' => $data_kriteria] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7)): ?>
<?php $component = $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7; ?>
<?php unset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = App\View\Components\InputText::resolve(['name' => 'nama','label' => 'Nama Sub Kriteria'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputText::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = App\View\Components\InputText::resolve(['name' => 'bobot','label' => 'Bobot Sub Kriteria','placeholder' => 'Contoh : 2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputText::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                            <button class="bg-green-500 text-white font-semibold px-3 py-2 rounded-lg"
                                type="submit">Tambah</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/pages/sub_kriteria_add.blade.php ENDPATH**/ ?>