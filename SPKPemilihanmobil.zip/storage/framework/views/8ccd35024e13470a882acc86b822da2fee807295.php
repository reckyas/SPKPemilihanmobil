<?php $__env->startSection('title', 'Tambah Data Mobil'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto w-full p-5 sm:p-10">
        <div class="flex sm:gap-2 flex-wrap sm:flex-nowrap">
            <div class="sm:w-3/12 mb-2 w-full">
                <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve(['active' => 'mobil'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
            </div>
            <div class="sm:w-9/12 w-full">
                <div class="px-5 border rounded-lg">
                    <div class="my-2">
                        <h1 class="text-2xl text-slate-700 font-semibold">Tambah Mobil</h1>
                    </div>
                    <div class="flex justify-end py-5">
                        <a href="/mobil"
                            class="px-3 py-2 font-semibold text-white bg-slate-500 hover:bg-green-700 rounded-lg">Batal</a>
                    </div>
                    <div class="py-5">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-red-600"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php if(session()->has('status')): ?>
                            <?php if(session()->get('status') == 'sukses'): ?>
                                <div class="p-3 rounded-lg bg-green-500 text-white"><?php echo e(session()->get('message')); ?></div>
                            <?php else: ?>
                                <div class="p-3 rounded-lg bg-red-500 text-white"><?php echo e(session()->get('message')); ?></div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <form action="/mobil/add" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = App\View\Components\InputText::resolve(['name' => 'nama','label' => 'Nama Mobil'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputText::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = App\View\Components\InputText::resolve(['name' => 'tahun_keluar','label' => 'Tahun Keluar','placeholder' => 'Contoh : 2022'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputText::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = App\View\Components\InputText::resolve(['name' => 'harga','label' => 'Harga','placeholder' => 'Masukan harga asli, contoh : 150000000'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputText::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7 = $component; } ?>
<?php $component = App\View\Components\InputSelect::resolve(['name' => 'model','label' => 'Model','options' => [
                                [
                                    'label' => '-- Pilih model mobil --',
                                    'value' => '',
                                ],
                                [
                                    'label' => 'Pick-up',
                                    'value' => 'Pick-up',
                                ],
                                [
                                    'label' => 'Sedan',
                                    'value' => 'Sedan',
                                ],
                                [
                                    'label' => 'City car',
                                    'value' => 'City car',
                                ],
                                [
                                    'label' => 'SUV',
                                    'value' => 'SUV',
                                ],
                                [
                                    'label' => 'MVP',
                                    'value' => 'MVP',
                                ],
                            ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7)): ?>
<?php $component = $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7; ?>
<?php unset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7 = $component; } ?>
<?php $component = App\View\Components\InputSelect::resolve(['name' => 'transmisi','label' => 'Transmisi','options' => [
                                [
                                    'label' => '-- Pilih transmisi mobil --',
                                    'value' => '',
                                ],
                                [
                                    'label' => 'Manual',
                                    'value' => 'Manual',
                                ],
                                [
                                    'label' => 'Automatic',
                                    'value' => 'Automatic',
                                ],
                            ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7)): ?>
<?php $component = $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7; ?>
<?php unset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = App\View\Components\InputText::resolve(['name' => 'kapasitas_mesin','label' => 'Kapasitas Mesin','placeholder' => 'Contoh : 1200'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputText::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532 = $component; } ?>
<?php $component = App\View\Components\InputText::resolve(['name' => 'kapasitas_penumpang','label' => 'Kapasitas Penumpang','placeholder' => 'Contoh : 5'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputText::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532)): ?>
<?php $component = $__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532; ?>
<?php unset($__componentOriginaldeabf38831837ca0c0c83f4f78f687d6d9de3532); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7 = $component; } ?>
<?php $component = App\View\Components\InputSelect::resolve(['name' => 'konsumsi_bbm','label' => 'Konsumsi BBM','options' => [
                                [
                                    'label' => '-- Pilih konsumsi BBM --',
                                    'value' => '',
                                ],
                                [
                                    'label' => 'Boros',
                                    'value' => 'Boros',
                                ],
                                [
                                    'label' => 'Sedang',
                                    'value' => 'Sedang',
                                ],
                                [
                                    'label' => 'Irit',
                                    'value' => 'Irit',
                                ],
                            ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7)): ?>
<?php $component = $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7; ?>
<?php unset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7 = $component; } ?>
<?php $component = App\View\Components\InputSelect::resolve(['name' => 'ketersediaan_sparepart','label' => 'Ketersediaan Sparepart','options' => [
                                    [
                                        'label' => '-- Pilih ketersediaan sparepart --',
                                        'value' => '',
                                    ],
                                    [
                                        'label' => 'Langka',
                                        'value' => 'Langka',
                                    ],
                                    [
                                        'label' => 'Mahal',
                                        'value' => 'Mahal',
                                    ],
                                    [
                                        'label' => 'Murah',
                                        'value' => 'Murah',
                                    ],
                                    [
                                        'label' => 'Banyak Tersedia',
                                        'value' => 'Banyak Tersedia',
                                    ],
                                ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputSelect::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7)): ?>
<?php $component = $__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7; ?>
<?php unset($__componentOriginal92426030d0e3b77565cd491bb958d348095c03f7); ?>
<?php endif; ?>
                            <div class="mb-2">
                                <label for="gambar">
                                    <span class="text-slate-700 font-semibold">Gambar</span>
                                    <input type="file"
                                        class="px-3 py-2 border-2 border-slate-500 mt-1 rounded-lg outline-none focus:ring-2 focus:ring-blue-400 text-slate-700 font-semibold w-full"
                                        name="gambar" id="gambar" placeholder="Pilih gambar mobil" required>
                                </label>
                            </div>
                            <button class="bg-green-500 text-white font-semibold px-3 py-2 rounded-lg"
                                type="submit">Tambah</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/pages/mobil_add.blade.php ENDPATH**/ ?>