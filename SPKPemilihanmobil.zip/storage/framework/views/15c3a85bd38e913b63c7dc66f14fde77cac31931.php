<?php $__env->startSection('title', 'Mobil'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto w-full p-5 sm:p-10">
        <div class="flex sm:gap-2 flex-wrap sm:flex-nowrap">
            <div class="sm:w-3/12 mb-2 w-full">
                <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = App\View\Components\Sidebar::resolve(['active' => 'mobil'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
            </div>
            <div class="sm:w-9/12 w-full">
                <div class="px-5 border rounded-lg">
                    <div class="my-2">
                        <h1 class="text-2xl text-slate-700 font-semibold">List Mobil</h1>
                    </div>
                    <div class="flex justify-end py-5">
                        <a href="/tambah-mobil"
                            class="px-3 py-2 font-semibold text-white bg-green-500 hover:bg-green-700 rounded-lg">Tambah</a>
                    </div>
                    <div class="py-5 overflow-auto">
                        <?php if(session()->has('status')): ?>
                            <?php if(session()->get('status') == 'sukses'): ?>
                                <div class="p-3 mb-3 rounded-lg bg-green-500 text-white"><?php echo e(session()->get('message')); ?>

                                </div>
                            <?php else: ?>
                                <div class="p-3 mb-3 rounded-lg bg-red-500 text-white"><?php echo e(session()->get('message')); ?></div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <table class="table-auto border border-collapse border-slate-500">
                            <thead>
                                <tr class="bg-slate-300">
                                    <th class="border border-slate-600 px-1">No.</th>
                                    <th class="border border-slate-600 px-1">Gambar</th>
                                    <th class="border border-slate-600 px-1">Nama</th>
                                    <th class="border border-slate-600 px-1">Tahun Keluar</th>
                                    <th class="border border-slate-600 px-1">Harga</th>
                                    <th class="border border-slate-600 px-1">Model</th>
                                    <th class="border border-slate-600 px-1">Transmisi</th>
                                    <th class="border border-slate-600 px-1">Kapasitas Mesin (CC)</th>
                                    <th class="border border-slate-600 px-1">Kapasitas Penumpang</th>
                                    <th class="border border-slate-600 px-1">Konsumsi BBM</th>
                                    <th class="border border-slate-600 px-1">Ketersediaan Sparepart</th>
                                    <th class="border border-slate-600 px-1">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $mobil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="border border-slate-600 px-1"><?php echo e($loop->iteration); ?></td>
                                        <td class="border border-slate-600 px-1"><img
                                                src="<?php echo e(asset('/storage/mobil/' . $item->gambar)); ?>"
                                                alt="<?php echo e($item->gambar); ?>"></td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->nama); ?></td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->tahun_keluar); ?></td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->harga); ?></td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->model); ?></td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->transmisi); ?></td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->kapasitas_mesin); ?> cc</td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->kapasitas_penumpang); ?></td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->konsumsi_bbm); ?></td>
                                        <td class="border border-slate-600 px-1"><?php echo e($item->ketersediaan_sparepart); ?></td>
                                        <td class="border border-slate-600 px-1 py-1">
                                            <a href="/mobil/<?php echo e($item->id); ?>"
                                                class="px-2 py-1 bg-yellow-500 text-white rounded font-semibold mb-1 inline-block">E</a>
                                            <form action="post"></form>
                                            <form action="<?php echo e(route('mobil.delete', $item->id)); ?>" method="post" onsubmit="return confirm('Apakah anda yakin akan menghapus data ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="px-2 py-1 bg-red-500 text-white rounded font-semibold inline-block">X</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($mobil->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/pages/mobil_all.blade.php ENDPATH**/ ?>