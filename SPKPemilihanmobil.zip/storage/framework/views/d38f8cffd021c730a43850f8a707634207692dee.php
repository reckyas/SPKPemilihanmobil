<div class="mb-2">
    <label for="<?php echo e($name); ?>">
        <span class="text-slate-700 font-semibold"><?php echo e($label); ?></span>
        <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" <?php if($required): ?> required <?php endif; ?>
            class="px-3 py-2 border-2 border-slate-500 mt-1 rounded-lg outline-none focus:ring-2 focus:ring-blue-400 text-slate-700 font-semibold w-full">
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($selected && $selected == $option['value']): ?>
                    <option value="<?php echo e($option['value']); ?>" selected><?php echo e($option['label']); ?></option>
                <?php elseif(old($name) == $option['value']): ?>
                    <option value="<?php echo e($option['value']); ?>" selected><?php echo e($option['label']); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($option['value']); ?>"><?php echo e($option['label']); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>
</div>
<?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/components/input-select.blade.php ENDPATH**/ ?>