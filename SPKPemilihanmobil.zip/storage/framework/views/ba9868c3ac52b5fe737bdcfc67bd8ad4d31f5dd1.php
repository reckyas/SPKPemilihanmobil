<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title', 'SPK Pemilihan Mobil'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo $__env->yieldPushContent('head'); ?>
</head>

<body>
    <!-- Header -->
    <section>
        <div class="w-full bg-red-500">
            <div class="flex justify-between p-5 container mx-auto">
                <div class="text-slate-200 font-bold sm:text-4xl">
                    <a href="/">SPK Pemilihan Mobil</a>
                </div>
                <div class="flex text-slate-200 font-semibold">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="/dashboard" class="self-center mr-2"><?php echo e(auth()->user()->name); ?> |</a>
                        <form action="/logout" class="flex item-center" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="self-center">Keluar</button>
                        </form>
                    <?php else: ?>
                        <a href="/login" class="self-center">Masuk</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Content -->
    <section>
        <?php echo $__env->yieldContent('content'); ?>
    </section>
</body>

</html>
<?php /**PATH E:\PROJECT\TUGAS AKHIR\FIAN\SPKPemilihanmobil\resources\views/layout/main.blade.php ENDPATH**/ ?>